#ifndef LOGIN_H
#define LOGIN_H

// Include library yang diperlukan
#include "lihat_tiketkonser.h"

// Deklarasi fungsi login
int login();

#endif


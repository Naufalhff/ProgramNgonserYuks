#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Person {
    char nama_lengkap[100];
    char email[100];
    char nomor_telepon[20];
} Person;

typedef struct QueueNode {
    Person info;
    struct QueueNode* next;
} QueueNode;

typedef struct Queue {
    QueueNode* front;
    QueueNode* rear;
} Queue;

void initQueue(Queue* q) {
    q->front = NULL;
    q->rear = NULL;
}

int isEmpty(Queue* q) {
    return (q->front == NULL);
}

void enqueue(Queue* q, Person p) {
    QueueNode* newNode = (QueueNode*) malloc(sizeof(QueueNode));
    if (newNode != NULL) {
        newNode->info = p;
        newNode->next = NULL;
        if (isEmpty(q)) {
            q->front = newNode;
            q->rear = newNode;
        } else {
            q->rear->next = newNode;
            q->rear = newNode;
        }
    }
}

Person dequeue(Queue* q) {
    if (isEmpty(q)) {
        printf("Queue is empty, cannot dequeue.\n");
        exit(EXIT_FAILURE);
    }
    QueueNode* temp = q->front;
    Person p = temp->info;
    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(temp);
    return p;
}

void displayQueue(Queue* q) {
    QueueNode* temp = q->front;
    while (temp != NULL) {
        printf("Nama Lengkap: %s, Email: %s, Nomor Telepon: %s\n", temp->info.nama_lengkap, temp->info.email, temp->info.nomor_telepon);
        temp = temp->next;
    }
}

void registrasi(Queue* q) {
    Person p;
    
    // Meminta pengguna untuk memasukkan informasi registrasi
    printf("Masukkan Nama Lengkap: ");
    scanf("%s", p.nama_lengkap);
    clearInputBuffer();

    printf("Masukkan Email: ");
    scanf("%s", p.email);
    clearInputBuffer();

    printf("Masukkan Nomor Telepon: ");
    scanf("%s", p.nomor_telepon);
    clearInputBuffer();

    // Menambahkan orang ke antrian
    enqueue(q, p);
    printf("Registrasi berhasil. Silakan menunggu untuk giliran Anda.\n");
}

void simpanDataRegistrasi(Queue* q) {
    FILE *file = fopen("data_registrasi.txt", "a");
    if (file == NULL) {
        printf("Error: Gagal membuka file.\n");
        return;
    }

    // Menyimpan data registrasi dari antrian ke dalam file
    while (!isEmpty(q)) {
        Person p = dequeue(q);
        fprintf(file, "%s %s %s\n", p.nama_lengkap, p.email, p.nomor_telepon);
    }

    // Menutup file
    fclose(file);
    printf("Data registrasi berhasil disimpan.\n");
}

// Fungsi untuk membersihkan input buffer
void clearInputBuffer() {
    while (getchar() != '\n');
}

// Fungsi untuk menampilkan halaman khusus registrasi
void tampilan_halaman_registrasi() {
    printf("Halaman Registrasi:\n");
    // Tampilkan informasi atau instruksi untuk registrasi di sini
}



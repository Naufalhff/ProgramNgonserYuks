#include "lihat_tiketkonser.h"
#include <stdio.h>

int last_choice=0;

void lihat_tiket() {
    printf("Menu Lihat Tiket Konser:\n");
    printf("Press any key to continue:\n ");
}


void lihat_detail_konser_band(int pilihan_band) {
	// Membersihkan layar konsol
    system("cls");
    	
    // Menampilkan detail konser dari band/musisi yang dipilih
    switch (pilihan_band) {
        case 1:
        	printf("Daftar Band/Musisi yang akan tampil di konser:\n");
			printf("			 ___             _  _  _      _  _         ___  _        _\n");
			printf("			| _ \\ ___  __ _ | |(_)| |_ | || |       / __|| | _  _ | |__\n");
			printf("			|   // -_) / _` || || ||  _| \\_. |      | (__ | || || ||  _ \\\n") ;
			printf("			|_|_ \\___|\\__/_||_||_| \\__||__/        \\___||_| \\_._||____/\n");
            printf("Detail Konser Reality Club:\n");
            printf("Genre Musik: Rock\n");
            printf("Nama Band: Band A\n");
            printf("Lagu-lagu yang akan dipentaskan: Lagu 1, Lagu 2, Lagu 3\n");
            printf("Harga Tiket Konser: Rp. 100.000\n");
            printf("Ketersediaan Tiket Konser: 500 tiket\n");
            break;
        case 2:
        	printf("                            _____  _                   _                                   \n");
   			printf("                           |_   _|| |_   ___        _ | | __ _  _ _   ___ ___  _ _         \n");
    		printf("                             | |  |   \\ / -_)      | || |/ _` || ' \\ (_-// -_)| ' \\        \n");
    		printf("                             |_|  |_||_|\\___|       \\__/ \\__/_||_||_|/__/\___||_||_|      \n");
    		printf("																\n");
    		printf("																\n");
    		printf("																\n");
            printf("Detail Konser :\n");
            printf("Genre Musik: Rock\n");
            printf("Lagu-lagu yang akan dipentaskan: \n");
            printf("1. Kau Pemeran Utama		\n");
            printf("2. Ku Bukan Mesin Lotremu	\n");
            printf("3. Langit Tak Seharusnya Biru		\n");
            printf("																\n");
    		printf("																\n");
            printf("Harga Tiket Konser: Rp. 150.000\n");
            printf("Ketersediaan Tiket Konser: 700 tiket\n");
            break;
        case 3:
        	printf("				 ___  _          _  _                               ____  \n");
    		printf("				/ __|| |_   ___ (_)| | __ _        ___  _ _         |__  | \n");
    		printf("				\\__ \\|   \\ / -_)| || |/ _` |      / _ \\| ' \\          / /  \n");
    		printf("				|___/|_||_| \___||_||_|\\__/_|      \\___/|_||_|        /_/   \n");
    		printf("																\n");
    		printf("																\n");
    		printf("																\n");
            printf("Detail Konser :\n");
            printf("Genre Musik: Pop\n");
            printf("Tanggal Konser : 25 Juni 2024 \n");
            printf("Jam Show Konser : 17.00-21.00 WIB \n");
            printf("Lagu-lagu yang akan dipentaskan: \n");
            printf("1. DAN		\n");
            printf("2. Seberapa Pantas	\n");
            printf("3. Sephia			\n");
            printf("Harga Tiket Konser: Rp. 200.000\n");
            printf("Ketersediaan Tiket Konser: 500tiket\n");
            break;
            default:
            printf("Pilihan tidak valid.\n");
            return;
	}
	printf("\nApakah anda ingin kembali ke halaman sebelumnya? [y/n]: ");
    char choice;
    scanf(" %c", &choice);

    // Memeriksa pilihan pengguna
    if (choice == 'y' || choice == 'Y') {
        // Kembali ke halaman sebelumnya
        lihat_band_musisi_dan_detail();
    } else {
        // Tidak kembali ke halaman sebelumnya, program selesai
        printf("\nTerima kasih! Program selesai.\n");
    }
}



void lihat_band_musisi_dan_detail() {
	// Membersihkan layar konsol
    system("cls");
    // Simulasi daftar band/musisi yang akan tampil di konser
    printf("Daftar Band/Musisi yang akan tampil di konser:\n");
    printf("1.			\n");
	printf(" ___             _  _  _    _  _         ___  _        _\n");
	printf("| _ \\ ___  __ _ | |(_)| |_ | || |       / __|| | _  _ | |__\n");
	printf("|   // -_) / _` || || ||  _| \\_. |      | (__ | || || ||  _ \\\n") ;
	printf("|_|_ \\___|\\__/_||_||_| \\__| |__/        \\___||_| \\_._||____/\n");
    printf("2. 			\n");
    printf(" _____  _                   _                                   \n");
    printf("|_   _|| |_   ___        _ | | __ _  _ _   ___ ___  _ _         \n");
    printf("  | |  |   \\ / -_)      | || |/ _` || ' \\ (_-// -_)| ' \\        \n");
    printf("  |_|  |_||_|\\___|       \\__/ \\__/_||_||_|/__/\___||_||_|      \n");
    printf("3. 		 \n");
    
    printf(" ___  _          _  _                               ____  \n");
    printf("/ __|| |_   ___ (_)| | __ _        ___  _ _         |__  | \n");
    printf("\\__ \\|   \\ / -_)| || |/ _` |      / _ \\| ' \\          / /  \n");
    printf("|___/|_||_| \___||_||_|\\__/_|      \\___/|_||_|        /_/   \n");
    // Menampilkan pilihan untuk melanjutkan atau kembali
	printf("Pilih nomor band/musisi untuk melihat detail konser: ");
    int pilihan_band;
    scanf("%d", &pilihan_band);
    
    // Menyimpan pilihan terakhir pengguna
    last_choice = pilihan_band;
    
    lihat_detail_konser_band(pilihan_band);

}


    
    


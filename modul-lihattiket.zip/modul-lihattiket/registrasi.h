#ifndef REGISTRASI_H
#define REGISTRASI_H


// Include library yang diperlukan
#include "lihat_tiketkonser.h"

// Deklarasi fungsi registrasi
void registrasi();


typedef struct Person {
    char nama_lengkap[100];
    char email[100];
    char nomor_telepon[20];
} Person;

typedef struct QueueNode {
    Person info;
    struct QueueNode* next;
} QueueNode;

typedef struct Queue {
    QueueNode* front;
    QueueNode* rear;
} Queue;


#endif


#ifndef QUEUE_H
#define QUEUE_H

typedef struct Person {
    char nama_lengkap[100];
    char email[100];
    char nomor_telepon[20];
} Person;

typedef struct QueueNode {
    Person info;
    struct QueueNode* next;
} QueueNode;

typedef struct Queue {
    QueueNode* front;
    QueueNode* rear;
} Queue;

void initQueue(Queue* q);
int isEmpty(Queue* q);
void enqueue(Queue* q, Person p);
Person dequeue(Queue* q);
void displayQueue(Queue* q);
void simpanDataRegistrasi(Queue* q);

#endif // QUEUE_H


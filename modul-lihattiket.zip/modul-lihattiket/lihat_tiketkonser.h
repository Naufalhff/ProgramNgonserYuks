#ifndef LIHAT_TIKETKONSER_H
#define LIHAT_TIKETKONSER_H
#define MAX_USERS 100
#define USERNAME_LENGTH 20
#define PASSWORD_LENGTH 20
#define INFO_LENGTH 50
#define FILENAME "namaregistrasi.txt"

// Struktur data untuk menyimpan informasi pengguna
typedef struct {
    char username[USERNAME_LENGTH];
    char password[PASSWORD_LENGTH];
    char fullname[INFO_LENGTH];
    char email[INFO_LENGTH];
    char phone[INFO_LENGTH];
} User;

// Definisikan enum untuk kategori menu
typedef enum {
    GENRE_MUSIK,
    BAND_MUSISI,
    HARGA_TIKET,
    JADWAL_KONSER,
    KUOTA_TIKET
} Menu;

// Deklarasi fungsi-fungsi untuk menampilkan menu dan informasi tiket
void lihat_tiket();
void lihat_genre_musik();
void lihat_band_musisi();
void lihat_harga_tiket();
void lihat_jadwal_konser();
void lihat_kuota_tiket();
void register_user();
void save_users_to_file();
void load_users_from_file();

#endif


#include <stdio.h>
#include <stdlib.h>
#include "lihat_tiketkonser.h"
#include "registrasi.h "
#include "login.h"


int main() {
    Queue q;
    initQueue(&q);

    char kembali_ke_menu;
    char nama_lengkap[100];
    char email[100];
    char nomor_telepon[15];
    int is_registered = 0;
    char nama_lengkap_reg[100];
    char email_reg[100];
    char nomor_telepon_reg[20];

    do {
        int pilihan_menu;

        // Menampilkan menu registrasi atau login
        // Menampilkan menu registrasi atau login
		system("cls");
        printf("                                                                              \n");
        printf("                                    _  _   ___   ___   _  _  ___  ___  ___          `__   __ _   _  _  __ ___  ___   _ \n");
        printf("                                   | \\| | / __| / _ \\ | \\| |/ __|| __|| _ \\      \\ \\ / /| | | || |/ // __|/ __| | |\n");
        printf("                                   | .  || (_ || (_) || .  |\\__ \\| _| |   /       \\   / | |_| ||   < \\__ \\\\__ \\ |_|\n");
        printf("                      \\!!!/        |_|\\_| \\___| \\___/ |_|\\_||___/|___||_|_\\        |_|   \\___/ |_|\\_\\|___/|___/ (_)\n");
        printf("                      |===|                                                                                              \n");
        printf("                      |!!!|                                                                                             \n");
        printf("                      |!!!|                                                                                             \n");
        printf("                      |!!!|                                                                                             \n");
        printf("                      |!!!|                                                                                             \n");
        printf("                     _|!!!|__               1. Registrasi                                                                          \n");
        printf("                   .+=|!!!|--.`.            2. Login                                                                          \n");
        printf("                 .'   |!!!|   `\\            3. Tampilkan Antrian Registrasi                                                       \n");
        printf("                /     !===!     \\           4. Simpan Data Registrasi                                                                          \n");
        printf("               |    /|!!!|\\    ||           5. Keluar                                                                           \n");
        printf("                \\   \\!!!!!/   //                                                                                       \n");
        printf("                 )   `==='   ((                                                                                     \n");
        printf("               .'    !!!!!    `..                                                                                      \n");
        printf("              /      !!!!!      \\                                                                                      \n");
        printf("             |       !!!!!       ||                                                                                    \n");
        printf("             |       !!!!!       ||                                                                                    \n");
        printf("             |       !!!!!       ||                                                                                    \n");
        printf("              \\     =======     //                                                                                     \n");
        printf("                `.    ooooo     '                                                                                      \n");
        printf("                 `-._______.-'   															");
        printf("\n");
        printf("\n");
        printf("\n");
        printf("\n");
        printf("Pilih menu: ");
        scanf("%d", &pilihan_menu);
        clearInputBuffer();

        switch (pilihan_menu) {
            case 1:
                // Memanggil fungsi registrasi dan menyimpan informasi registrasi
                {
                    Person p;
                    system("cls");
                    printf("Masukkan Nama Lengkap: ");
                    scanf("%s", p.nama_lengkap);
                    clearInputBuffer();
                    printf("Masukkan Email: ");
                    scanf("%s", p.email);
                    clearInputBuffer();
                    printf("Masukkan Nomor Telepon: ");
                    scanf("%s", p.nomor_telepon);
                    clearInputBuffer();
                    enqueue(&q, p);
                    printf("Registrasi berhasil. Silakan menunggu untuk giliran Anda.\n"); 
                }
                break;
            case 2:
            	system("cls");
                if (login(nama_lengkap_reg, email_reg, nomor_telepon_reg)) {
                    // Menampilkan menu lihat tiket konser jika login berhasil
                    lihat_tiket();
                    int pilihan_band;
                    lihat_band_musisi_dan_detail();
                    printf("Pilih nomor band/musisi untuk melihat detail konser: ");
                    scanf("%d", &pilihan_band);
                    lihat_detail_konser_band(pilihan_band);
                } else {
                    printf("Login gagal. Silakan coba lagi.\n");
                }
                break;
            case 3:
            	system("cls");
                printf("Daftar Antrian Registrasi:\n");
                displayQueue(&q);
                break;
            case 4:
            	system("cls");
                simpanDataRegistrasi(&q);
                break;
            case 5:
            	system("cls");
                printf("Keluar dari program.\n");
                return 0;
            default:
                printf("Pilihan tidak valid.\n");
                break;
        }

        printf("Kembali ke menu awal? (y/n): ");
        scanf(" %c", &kembali_ke_menu); // Spasi sebelum %c untuk menghindari masalah dengan karakter newline sebelumnya
        clearInputBuffer();

    } while (kembali_ke_menu == 'y' || kembali_ke_menu == 'Y');

    return 0;
}

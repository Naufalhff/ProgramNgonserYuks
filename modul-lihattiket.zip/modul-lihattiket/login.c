#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Fungsi untuk melakukan login
int login() {
    char nama_lengkap[100];
    char email[100];
    char nomor_telepon[20];

    // Meminta pengguna untuk memasukkan informasi login
    printf("Masukkan Nama Lengkap: ");
    scanf("%s", nama_lengkap);

    printf("Masukkan Email: ");
    scanf("%s", email);

    printf("Masukkan Nomor Telepon: ");
    scanf("%s", nomor_telepon);

    // Buka file untuk membaca data registrasi
    FILE *file = fopen("data_registrasi.txt", "r");
    if (file == NULL) {
        printf("Error: Gagal membuka file.\n");
        return 0;
    }

    // Membaca data registrasi dari file dan membandingkannya dengan data yang dimasukkan
    char buffer[255];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        char stored_nama_lengkap[100], stored_email[100], stored_nomor_telepon[20];
        sscanf(buffer, "%s %s %s", stored_nama_lengkap, stored_email, stored_nomor_telepon);
        if (strcmp(nama_lengkap, stored_nama_lengkap) == 0 && strcmp(email, stored_email) == 0 && strcmp(nomor_telepon, stored_nomor_telepon) == 0) {
            fclose(file);
            return 1; // Return 1 jika login berhasil
        }
    }

    // Menutup file
    fclose(file);

    return 0; // Return 0 jika login gagal
}


